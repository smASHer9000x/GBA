# GBA3.0

The BEST way to play your retro game library.

Wiki & Guides to hosting and creating a library: [wiki](https://github.com/Cattn/GBAv3/wiki)

## Help
You can get more help at our discord server [here](https://discord.gg/math-study-934807331668099142)

Or, at the wiki linked above.

## Credits

Lead Developer - Cattn
> Developed by MSG. 

